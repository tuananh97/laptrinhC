#include<iostream>
#include<fstream>
#include<cmath>
using namespace std;
int tinhtongdong(int a[100][100],int n,int sodong)
{
	int tong=0;
	for(int j=0;j<n;j++)
	{
		tong+=a[sodong][j];
	}
	return tong;
}
bool Kiemtranguyento(int n)
{
	if(n<2)
	{
		return false;
	}
	else if(n>2)
	{
		if(n%2==0)
		{
			return false;
		}
		for(int i=3;i<int(sqrt(n));i+=2)
		{
			if(n%i==0)
			{
				return false;
			}
		}
	}
	return true;
}
bool Kiemtrahoanchinh(int n)
{
	int tong=0;
	for(int i=0;i<=n;i++)
	{
		if(n%i==0)
		tong += i;
	}
	if(tong == n)
	{
	return true;
    }
    else 
	{
	return false;
    }
}
int main()
{
	int a[100][100];
	int n,m;
	ifstream file("xem2.txt",ios::in);
	file >> n; 
	cout<<n<<endl;
	file >> m;
	cout<<m<<endl;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			file >> a[i][j];
			cout<<a[i][j]<<" ";
		}
		cout<<"\n";
	}
	file.close();
	//2.Tim cac so hoan chinh
	ofstream file3("bai2.txt",ios::app);
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<m;j++)
		{
			if(Kiemtrahoanchinh(a[i][j])==true)
		    file3 <<a[i][j]<<endl;
		}
	}
	file3.close();
	//1.Tim cac chi so i ma tong tren hang i=tong tren hang i+1
	 ofstream file2("bai1.txt",ios::app) ;
	 for(int i=0;i<=m;i++)
	 { 
	 if(tinhtongdong(a,n,i)==tinhtongdong(a,n,i+1))
	 	{
	 	cout<<i<<endl;
		file2<<i<<endl;
	    }
	 }
	file2.close();
	
}
