#include<iostream>
#include<cmath>
#include<string>
using namespace std;
struct Hocsinh
{
	string hoten,maso;
	float diemtoan,diemly,diemhoa,diemtin,diemsinh,diemvan,diemsu,diemdia,diemanh,diemGDCD,diemGDQP,diemcongnghe;
	float diemtrungbinh;
	int xeploai;
};               
enum Xeploai
{
	G,TT,K,TB
};
typedef struct Hocsinh HOCSINH;
struct Node
{
	HOCSINH Data;
	struct Node *pnext;
};
typedef struct Node NODE;
struct List
{
	NODE *phead;
	NODE *ptail;
};
typedef struct List LIST;
void CreateList(LIST &l)
{
	l.phead=l.ptail=NULL;
};
NODE *Createhocsinh(HOCSINH data){
	NODE *p=new NODE;
	if(p==NULL)
	{ 
		return NULL;
	}
	p->Data=data;
	p->pnext=NULL;
	return p;
}
void Addtail(LIST &l,NODE *p)
{
	if(l.phead==NULL)
	{
		l.phead=l.ptail=p;
	}
	else
	{
		l.ptail->pnext=p;
		l.ptail=p;
	}
}
void Nhaphocsinh(HOCSINH &hs)
{
	fflush(stdin);
	cout<<"\Nhap vao ten hoc sinh: ";
	getline(cin,hs.hoten);
	cout<<"\nNhap vao ma so hoc sinh: ";
	getline(cin,hs.maso);
	cout<<"\nNhap vao diem toan: ";
	cin>> hs.diemtoan;
	cout<<"\nNhap vao diem ly: ";
	cin>> hs.diemly;
	cout<<"\nNhap vao diem hoa: ";
	cin>> hs.diemhoa;
	cout<<"\nNhap vao diem sinh: ";
	cin>> hs.diemsinh;
	cout<<"\nNhap vao diem tin: ";
	cin>> hs.diemtin;
	cout<<"\nNhap vao diem van: ";
	cin>> hs.diemvan;
	cout<<"\nNhap vao diem su: ";
	cin>> hs.diemsu;
	cout<<"\nNhap vao diem dia: ";
	cin>> hs.diemdia;
	cout<<"\nNhap vao diem anh: ";
	cin>> hs.diemanh;
	cout<<"\nNhap vao diem GDCD: ";
	cin>> hs.diemGDCD;
	cout<<"\nNhap vao diem GDQP: ";
	cin>> hs.diemGDQP;
	cout<<"\nNhap vao diem cong nghe: ";
	cin>> hs.diemcongnghe;
}
void Xuathocsinh(HOCSINH hs)
{
	cout<<"\nHo va ten: "<<hs.hoten;
	cout<<"\nMa so: "<<hs.maso;
	cout<<"\nDiem toan: "<<hs.diemtoan;
	cout<<"\nDIem ly: "<<hs.diemly;
	cout<<"\nDiem hoa: "<<hs.diemhoa;
	cout<<"\nDIem sinh: "<<hs.diemsinh;
	cout<<"\nDiem tin: "<<hs.diemtin;
	cout<<"\nDiem van: "<<hs.diemvan;
	cout<<"\nDiem su: "<<hs.diemsu;
	cout<<"\nDiem dia: "<<hs.diemdia;
	cout<<"\nDIem anh: "<<hs.diemanh;
	cout<<"\nDiem GDCD: "<<hs.diemGDCD;
	cout<<"\nDiem GDQP: "<<hs.diemGDQP;
	cout<<"\nDiem cong nghe: "<<hs.diemcongnghe;
	cout<<"\nDIem trung binh: "<<hs.diemtrungbinh;
	cout<<"\nXep loai: ";
	if(hs.xeploai==G) cout<<"Gioi ";
	if(hs.xeploai==TT) cout<<"Tien tien";
	if(hs.xeploai==K)  cout<<"Kha";
	if(hs.xeploai==TB) cout<<"Trung binh";
}
void Input(LIST &l)
{
	CreateList(l);
	int n;
	cout<<"\nNhap si so lop hoc: ";
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		HOCSINH data;
		Nhaphocsinh(data);
		NODE *p=Createhocsinh(data);
		Addtail(l,p);
	}
}
void Output(LIST l)
{
	int dem=1;
	for(NODE *p=l.phead;p!=NULL;p=p->pnext)
	{
		cout<<"\n-------------------------Thong tin hoc sinh thu "<< dem++<<" la---------------------------";
		Xuathocsinh(p->Data);
	}
}
void Tinhtrungbinh(LIST l)
{
   for(NODE *p=l.phead;p!=NULL;p=p->pnext)
   {
   	   p->Data.diemtrungbinh=(p->Data.diemtoan+p->Data.diemvan+p->Data.diemanh+p->Data.diemcongnghe+p->Data.diemGDCD+p->Data.diemGDQP+p->Data.diemhoa+p->Data.diemly+p->Data.diemsinh+p->Data.diemtin+p->Data.diemdia+p->Data.diemsu)/12;
   }
}
void Xeploai(LIST l)
{
	for(NODE *p=l.phead;p!=NULL;p=p->pnext)
	{
		if((p->Data.diemtrungbinh >= 8) && (p->Data.diemtoan >=8 || p->Data.diemvan >= 8)&&(p->Data.diemanh>=6.5)&&(p->Data.diemcongnghe>=6.5)&&(p->Data.diemGDCD>=6.5)&&(p->Data.diemGDQP>=6.5)&&(p->Data.diemly>=6.5) &&(p->Data.diemhoa>=6.5)&&(p->Data.diemsinh>=6.5) &&(p->Data.diemtin>=6.5) &&(p->Data.diemsu>=6.5)&&(p->Data.diemdia>=6.5))
		{
		p->Data.xeploai=G;
		}
		else if(p->Data.diemtrungbinh>=6.5&& (p->Data.diemtoan >=6.5 || p->Data.diemvan >= 6.5)&&(p->Data.diemanh>=5)&&(p->Data.diemcongnghe>=5)&&(p->Data.diemGDCD>=5)&&(p->Data.diemGDQP>=5)&&(p->Data.diemly>=5) &&(p->Data.diemhoa>=5)&&(p->Data.diemsinh>=5) &&(p->Data.diemtin>=5) &&(p->Data.diemsu>=5)&&(p->Data.diemdia>=5))
		{
			p->Data.xeploai=TT;
		}
		else if((p->Data.diemtrungbinh>=6.5 && (p->Data.diemtoan >=5 )&&(p->Data.diemvan >= 5)&&(p->Data.diemanh>=5)&&(p->Data.diemcongnghe>=5)&&(p->Data.diemGDCD>=5)&&(p->Data.diemGDQP>=5)&&(p->Data.diemly>=5) &&(p->Data.diemhoa>=5)&&(p->Data.diemsinh>=5) &&(p->Data.diemtin>=5) &&(p->Data.diemsu>=5)&&(p->Data.diemdia>=5)))
		{
			p->Data.xeploai==K;
		}
		else if(p->Data.diemtrungbinh>=5)
		{
			p->Data.xeploai=TB;
		}
	}
}
int main()
{
LIST l;
Input(l);
Tinhtrungbinh(l);
Xeploai(l);
Output(l);	
}
