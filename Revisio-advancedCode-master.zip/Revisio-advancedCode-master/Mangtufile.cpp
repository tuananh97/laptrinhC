#include<iostream>
#include<cmath>
#include<fstream>
#include<stdlib.h>
#include<vector>
using namespace std;
void Hoanvi(int &a,int &b)
{
	int temp=a;
	a=b;
	b=temp;
}
bool Kiemtranguyento(int n)
{
	if(n<2)
	{
		return false;
	}
	else if(n>2)
	{
		if(n%2==0)
		{
			return false;
		}
		for(int i=3;i<int(sqrt(n));i+=2)
		{
			if(n%i==0)
			{
				return false;
			}
		}
	}
	return true;
}
int main()
{
	//Doc mang tu file
	vector<int> numbers;
	ifstream in("mang.txt",ios::in);
	int number;
	while(in >> number)
	{
		numbers.push_back(number);
	}
	in.close();
	cout<<"mang can nhap la: "<<endl;
	for(int i=0;i<numbers.size();i++)
	{
		cout<<numbers[i]<<endl;
	}
   cout<<"\n1.Sap xep mang da duoc doc tu file";
   cout<<"\n2.In so nguyen to";
   cout<<"\n------------------------------------------------------------------------\n";
	//SU dung mang de lam cac cong viec sau
	int choice;
    cout<<" Nhap vao lua chon cua ban: ";
    cin>>choice;
	
	//1.Sap xep mang tang dan roi in ra file sapxep.txt
	if(choice==1)
{
	for(int i=0;i<numbers.size()-1;i++)
	{
		for(int j=i+1;j<numbers.size();j++)
		{
			if(numbers[i]<numbers[j])
			{
				Hoanvi(numbers[i],numbers[j]);
			}
		}
	}
	  ofstream File("sapxep.txt",ios::app);
		for(int i=0;i<numbers.size();i++)
	{
		File<<numbers[i]<<endl;
	}
	File.close();
}
	//2.Tim va ghi cac so nguyen to ra file songuyento.txt
	else if(choice==2)
{
	    ofstream File2("songuyento.txt",ios::app);
		for(int i=0;i<numbers.size();i++)
	{
		if(Kiemtranguyento(numbers[i])==true)
		File2<<numbers[i]<<endl;
	}
	File2.close();
}
    //3.Them 1 so vao sau mang da cho roi ghi ra file mang2.txt
    else if(choice==3)
{
	int phantu=100,vitri=3;
	for(int i=numbers.size()-1;i>=vitri;i--)
	{
		numbers[i+1]=numbers[i];
	}
	numbers[vitri]=phantu;
	ofstream File3("mang2.txt",ios::app);
	for(int i=0;i<numbers.size()+1;i++)
	{
		File3<<numbers[i]<<endl;
	}
	File3.close();
}
	return 0;
}
