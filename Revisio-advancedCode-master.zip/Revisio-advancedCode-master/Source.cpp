#include<iostream>
#include<conio.h>
using namespace std;
struct VeTau{
	char NgayGioKhoiHanh[15];
	char NgayGioDen[15];
	char GaDi[15];
	char GaDen[15];
	char LoaiTau[10];
	char LoaiCho[10];
	int SoToa;
	int SoGhe;
	VeTau *pnext;
};
struct List{
	VeTau *head, *tail;
};
void CreateList(List &l)
{
	l.head = l.tail = NULL;
}
VeTau* CreateVeTau(char NgayGioKhoiHanh[], char NgayGioDen[], char GaDi[], char GaDen[], char LoaiTau[], char LoaiCho[], int SoToa, int SoGhe)
{
	VeTau *p = new VeTau;
	if (p == NULL) exit(1);
	strcpy_s(p->NgayGioKhoiHanh, NgayGioKhoiHanh);
	strcpy_s(p->NgayGioDen, NgayGioDen);
	strcpy_s(p->GaDi, GaDi);
	strcpy_s(p->GaDen, GaDen);
	strcpy_s(p->LoaiTau, LoaiTau);
	strcpy_s(p->LoaiCho, LoaiCho);
	p->SoToa = SoToa;
	p->SoGhe = SoGhe;
	p->pnext = NULL;
	return p;
}
void AddTail(List &l, VeTau *p)
{
	if (l.head == NULL)
	{
		l.head = l.tail = p;
	}
	else
	{
		l.tail->pnext = p;
		l.tail = p;
	}
}
void Input(List &l)
{
	VeTau *p;
	char NgayGioKhoiHanh[15];
	char NgayGioDen[15];
	char GaDi[15];
	char GaDen[15];
	char LoaiTau[15];
	char LoaiCho[15];
	int SoToa;
	int SoGhe;
	int Sove;
	cout << "Moi nhap vao so ve can in : ";
	cin >> Sove;
	fflush(stdin);
	for (int i = 1; i <= Sove;i++){
		system("cls");
		cout << "Ngay,Gio Xuat Phat: ";
		cin.getline(NgayGioKhoiHanh, 15);
		cout << "Ngay,Gio Den: ";
		cin.getline(NgayGioDen, 15);
		cout << "Ga Di: ";
		cin.getline(GaDi, 15);
		cout << "Ga Den: ";
		cin.getline(GaDen, 15);
		cout << "Loai Tau : ";
		cin >> LoaiTau;
		cout << "Loai cho: ";
		cout << "1. Cung " << "          " << "2. Mem ";
		cin >> LoaiCho;
		cout << "So Toa: ";
		cin >> SoToa; 
		cout << "So Ghe: ";
		cin >> SoGhe;
		fflush(stdin);
		p = CreateVeTau(NgayGioKhoiHanh, NgayGioDen, GaDi, GaDen, LoaiTau, LoaiCho, SoToa, SoGhe);
		AddTail(l, p);
	}
}
void Xuat(VeTau *p)
{
	system("cls");
	cout << "Ngay, Gio Khoi Hanh: " << p->NgayGioKhoiHanh << endl << "Ngay, Gio Den: " << p->NgayGioDen << endl <<
		"Ga Di: " << p->GaDi << endl << "Ga Den: " << p->GaDen << endl;
    cout<<"Loai Tau: " << p->LoaiTau << endl << "Loai Cho: " << p->LoaiCho << endl <<
		"So Toa: " << p->SoToa << endl << "So Ghe: " << p->SoGhe << endl;
	_getch();
}
void Output(List &l)
{
	VeTau *p = l.head;
	while (p!=NULL){
		Xuat(p);
		p = p->pnext;
	}
	
}
void Lietke(List &l)
{
	fflush(stdin);
	cout << "Cac ve tau co ga den la Hue la: " << endl;
	VeTau *p = l.head;
	while (p!=NULL)
	{
		if (p->GaDen == "Hue")
		{
			Xuat(p);
		}
		p = p->pnext;
	}
	
}
int main()
{
	List l;
	CreateList(l);
	Input(l);
	Output(l);
	
	Lietke(l);
	system("Pause");
}