#include<iostream>
#include<conio.h>
#include<string>
using namespace std;

struct VeTau{
	string NgayGioKhoiHanh,NgayGioDen, GaDi, GaDen, LoaiTau, LoaiCho;
	int SoToa;
	int SoGhe;
};
typedef struct VeTau VETAU;
struct Node
{
	VETAU Data;
	struct Node *pnext;
};
typedef struct Node NODE;
struct List{
	NODE *head;
	NODE *tail;
};
typedef struct List LIST;
void CreateList(LIST &l)
{
	l.head = l.tail = NULL;
}
NODE *CreateVeTau( VETAU data)
{
	NODE *p = new NODE;
	if (p == NULL)
	{
		return NULL;
	}
	p->Data = data;
	p->pnext = NULL;
	return p;
}
void AddTail(LIST &l, NODE *p)
{
	if (l.head == NULL)
	{
		l.head = l.tail = p;
	}
	else
	{
		l.tail->pnext = p;
		l.tail = p;
	}
}

void Nhapvetau(VETAU &vt)
{

	fflush(stdin);
	cout << "\Nhap vao ngay khoi hanh: ";
	getline(cin, vt.NgayGioKhoiHanh);
	cout << "Ngay,Gio Den: ";
	getline(cin, vt.NgayGioDen);
	cout << "Ga Di: ";
	getline(cin, vt.GaDi);
	cout << "Ga Den: ";
	getline(cin, vt.GaDen);
	cout << "Loai Tau : ";
	getline(cin, vt.LoaiTau);
	cout << "Loai cho: ";
	getline(cin, vt.LoaiCho);
	cout << "So Toa: ";
	cin >> vt.SoToa;
	cout << "So Ghe: ";
	cin >> vt.SoGhe;
}
void Input(LIST &l)
{
	CreateList(l);
	int n;
	cout << "\nNhap so luong ve tau can nhap: ";
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		VETAU data;
		Nhapvetau(data);
		NODE *p = CreateVeTau(data);
		AddTail(l, p);
	}
}
void Xuat(VETAU vt)
{

	cout << "\nNgay, Gio Khoi Hanh: " << vt.NgayGioKhoiHanh;
	cout << "\nNgay, Gio Den: " << vt.NgayGioDen;
	cout << "\nGa Di: " << vt.GaDi;
	cout<< "\nGa Den: " << vt.GaDen;
	cout << "\nLoai Tau: " << vt.LoaiTau;
	cout << "\nLoai Cho: " << vt.LoaiCho;
	cout << "\nSo Toa: " << vt.SoToa;
	cout<< "\nSo Ghe: " << vt.SoGhe<<endl;
	
}
void Output(LIST l)
{
	int dem = 1;
	for(NODE *p=l.head;p!=NULL;p=p->pnext)
	{ 
		cout << "------------Thong tin ve tau thu " << dem++ << "----------------"<<endl;
		Xuat(p->Data);
	}
	
}
void TimKiem( LIST l)
{ 
	cout << "--------------------------------Cac ve co ga den la Hue la-------------------------------" << endl;
	for (NODE *p = l.head; p != NULL; p = p->pnext)
	{
		if (p->Data.GaDen == "Hue")
			Xuat(p->Data);
	}
}
void TimKiem2(LIST l)
{
	cout << "--------------------------------Cac ve co ngay di la 1/6/2016-------------------------------" << endl;
	for (NODE *p = l.head; p != NULL; p = p->pnext)
	{
		if (p->Data.NgayGioKhoiHanh == "1/6/2016")
			Xuat(p->Data);
	}
}
//void Lietke(List &l)
//{
	//fflush(stdin);
	//cout << "Cac ve tau co ga den la Hue la: " << endl;
	//for (NODE *p = l.head; p != NULL; p = p->pnext)
	//{
	//}
//}
int main()
{
	LIST l;
	Input(l);
	Output(l);
	TimKiem2(l);
	system("Pause");
}
